package com.dobmob.doblist.events;

public interface OnLoadMoreListener {

	public void onLoadMore(int totalItemCount);

}
