package com.stripe.example;

import com.stripe.android.model.Token;

public interface TokenList {
    public void addToList(Token token);
}
